You don't need to copy the DLLs anywhere because the main program has copies of them embedded within it.

See the main readme for details.
