//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Win7Elevate.rc
//
#define IDC_MYICON                      2
#define IDD_WIN7ELEVATE_DIALOG          102
#define IDI_WIN7ELEVATE                 107
#define IDI_SMALL                       108
#define IDD_EMBEDDED_DLL                110
#define IDR_MAINFRAME                   128
#define IDC_BUTTON_INJECT               129
#define IDC_BUTTON_ELEVATE              130
#define IDC_BUTTON_NOELEVATE            131
#define IDC_BUTTON_PROCESS_REFRESH      132
#define IDC_LIST_PROCESSES              133
#define IDC_EDITDROP_COMMAND            134
#define IDC_EDIT_ARGUMENTS              135
#define IDC_EDIT_DIRECTORY              136
#define IDC_BUTTON_LOGIC                137
#define IDC_BUTTON_URL                  138
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
